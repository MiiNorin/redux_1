const Home = () => {
    return ( 
        <div>
            <h2>React JS CRUD using REDUX & JSON Server</h2>
        </div>
     );
}
 
export default Home;